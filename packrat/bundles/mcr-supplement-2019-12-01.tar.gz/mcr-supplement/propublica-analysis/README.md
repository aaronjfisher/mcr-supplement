To re-run, use

```{r}
library(knitr)
knit2html('propublica_kernel.rmd')
```

Intermediate results are stored in the R_output_files folder
